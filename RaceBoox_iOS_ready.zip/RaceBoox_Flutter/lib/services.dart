import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:io';

import 'package:geolocator/geolocator.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class StoreService {
  static const _settings = 'rb_settings';
  static const _history = 'rb_history';
  static const _trips = 'rb_trips';
  static const _todayDate = 'rb_today_date';
  static const _todayDist = 'rb_today_dist';
  static const _todayDur = 'rb_today_dur';
  late final SharedPreferences _prefs;

  Future<void> init() async => _prefs = await SharedPreferences.getInstance();

  AppSettings loadSettings() {
    final raw = _prefs.getString(_settings);
    if (raw == null || raw.isEmpty) return AppSettings();
    try { return AppSettings.decode(raw); } catch (_) { return AppSettings(); }
  }

  Future<void> saveSettings(AppSettings s) async => _prefs.setString(_settings, s.encode());

  List<RunRecord> loadHistory() {
    final raw = _prefs.getString(_history);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = (jsonDecode(raw) as List).map((e) => RunRecord.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      list.sort((a, b) => b.id.compareTo(a.id));
      return list;
    } catch (_) { return []; }
  }

  Future<void> addRun(RunRecord run) async {
    final list = loadHistory()..removeWhere((r) => r.id == run.id);
    list.insert(0, run);
    await _prefs.setString(_history, jsonEncode(list.map((e) => e.toJson()).toList()));
  }

  Future<void> deleteRun(int id) async {
    final list = loadHistory()..removeWhere((r) => r.id == id);
    await _prefs.setString(_history, jsonEncode(list.map((e) => e.toJson()).toList()));
  }

  Future<void> exportCsv(List<RunRecord> history, List<int> targets) async {
    final b = StringBuffer('tanggal,kendaraan,jenis,rentang_kmh,waktu_rentang_detik,reaction_detik');
    for (final d in targets) { b.write(',${d}m_detik'); }
    b.writeln(',top_speed_kmh,gps_acc_m');
    String iso(int ms) => DateTime.fromMillisecondsSinceEpoch(ms).toIso8601String();
    for (final h in history) {
      b.write('${iso(h.dateMs)},${h.vehicleName.replaceAll(',', ' ')},${h.kind},');
      b.write(h.kind == 'range' ? '${h.rangeFromKmh.toStringAsFixed(0)}-${h.rangeToKmh.toStringAsFixed(0)},' : ',');
      b.write('${h.rangeTimeSec?.toStringAsFixed(3) ?? ''},${h.reactionSec?.toStringAsFixed(3) ?? ''}');
      for (final d in targets) b.write(',${h.splits[d]?.t.toStringAsFixed(3) ?? ''}');
      b.writeln(',${h.maxSpeedKmh.toStringAsFixed(2)},${h.gpsAccuracyM?.toStringAsFixed(1) ?? ''}');
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/raceboox_history.csv');
    await file.writeAsString(b.toString());
    await SharePlus.instance.share(ShareParams(files: [XFile(file.path)], text: 'RaceBoox history export'));
  }

  List<TripMeta> loadTrips() {
    final raw = _prefs.getString(_trips);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = (jsonDecode(raw) as List).map((e) => TripMeta.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      list.sort((a, b) => b.startMs.compareTo(a.startMs));
      return list;
    } catch (_) { return []; }
  }

  Future<void> saveTrip(TripMeta meta, List<TripPoint> points) async {
    final list = loadTrips()..removeWhere((e) => e.id == meta.id)..insert(0, meta);
    await _prefs.setString(_trips, jsonEncode(list.map((e) => e.toJson()).toList()));
    await _prefs.setString('trip_${meta.id}', jsonEncode(points.map((e) => e.toJson()).toList()));
  }

  List<TripPoint> loadTripPoints(int id) {
    final raw = _prefs.getString('trip_$id');
    if (raw == null) return [];
    try { return (jsonDecode(raw) as List).map((e) => TripPoint.fromJson(List<dynamic>.from(e as List))).toList(); } catch (_) { return []; }
  }

  Future<void> deleteTrip(int id) async {
    final list = loadTrips()..removeWhere((e) => e.id == id);
    await _prefs.setString(_trips, jsonEncode(list.map((e) => e.toJson()).toList()));
    await _prefs.remove('trip_$id');
  }

  (double, int) todayStats() {
    final now = DateTime.now();
    final key = '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    if (_prefs.getString(_todayDate) != key) return (0, 0);
    return (_prefs.getDouble(_todayDist) ?? 0, _prefs.getInt(_todayDur) ?? 0);
  }

  Future<void> saveTodayStats(double dist, int durMs) async {
    final now = DateTime.now();
    final key = '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    await _prefs.setString(_todayDate, key);
    await _prefs.setDouble(_todayDist, dist);
    await _prefs.setInt(_todayDur, durMs);
  }

  Future<void> exportGpx(TripMeta meta, List<TripPoint> points) async {
    final b = StringBuffer('<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="RaceBoox" xmlns="http://www.topografix.com/GPX/1/1"><trk><name>RaceBoox ${DateTime.fromMillisecondsSinceEpoch(meta.startMs)}</name><trkseg>');
    for (final p in points) {
      b.write('<trkpt lat="${p.lat}" lon="${p.lon}"><ele>${p.alt}</ele><time>${DateTime.fromMillisecondsSinceEpoch(p.t).toUtc().toIso8601String()}</time></trkpt>');
    }
    b.write('</trkseg></trk></gpx>');
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/raceboox_trip_${meta.id}.gpx');
    await file.writeAsString(b.toString());
    await SharePlus.instance.share(ShareParams(files: [XFile(file.path)], text: 'RaceBoox GPX export'));
  }
}

class MotionService {
  final StreamController<MotionReading> _controller = StreamController.broadcast();
  final StreamController<Position> _positionController = StreamController.broadcast();
  Stream<MotionReading> get stream => _controller.stream;
  Stream<Position> get positions => _positionController.stream;
  StreamSubscription<Position>? _positionSub;
  StreamSubscription<AccelerometerEvent>? _accSub;
  bool running = false;
  bool mountInBag = false;
  double calibrationPct = 0;
  double _distanceM = 0;
  Position? _last;
  double _lastAccelMagnitude = 9.8;
  DateTime _lastEmit = DateTime.fromMillisecondsSinceEpoch(0);
  double _sensorMotion = 0;

  Future<bool> start() async {
    if (running) return true;
    final service = await Geolocator.isLocationServiceEnabled();
    if (!service) {
      _controller.add(const MotionReading(speedKmh: 0, distanceM: 0, gpsAccuracyM: null, gpsFixOk: false, gpsReady: false, timeMs: 0, gpsMessage: 'GPS mati'));
      return false;
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      _controller.add(const MotionReading(speedKmh: 0, distanceM: 0, gpsAccuracyM: null, gpsFixOk: false, gpsReady: false, timeMs: 0, gpsMessage: 'Izin lokasi ditolak'));
      return false;
    }
    running = true;
    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.bestForNavigation, distanceFilter: 0),
    ).listen(_onPosition, onError: (_) {});
    _accSub = accelerometerEventStream(samplingPeriod: const Duration(milliseconds: 50)).listen((e) {
      final mag = math.sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
      _sensorMotion = (mag - _lastAccelMagnitude).abs();
      _lastAccelMagnitude = mag;
    });
    try {
      final p = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.bestForNavigation));
      _onPosition(p);
    } catch (_) {}
    return true;
  }

  void _onPosition(Position p) {
    _positionController.add(p);
    final prev = _last;
    if (prev != null) {
      final d = Geolocator.distanceBetween(prev!.latitude, prev.longitude, p.latitude, p.longitude);
      final dt = (p.timestamp.millisecondsSinceEpoch - prev.timestamp.millisecondsSinceEpoch) / 1000.0;
      if (d < 250 && dt >= 0) _distanceM += d;
    }
    _last = p;
    final raw = (p.speed.isFinite && p.speed > 0 ? p.speed * 3.6 : 0.0);
    final corrected = (raw * (1 + calibrationPct / 100).clamp(0.5, 1.5)).toDouble();
    final acc = p.accuracy;
    final good = acc <= 20 && DateTime.now().difference(p.timestamp).inSeconds <= 3;
    final ready = acc <= 12 && good;
    final now = DateTime.now();
    if (now.difference(_lastEmit).inMilliseconds < 40) return;
    _lastEmit = now;
    _controller.add(MotionReading(speedKmh: corrected, distanceM: _distanceM, gpsAccuracyM: acc, gpsFixOk: good, gpsReady: ready, timeMs: p.timestamp.millisecondsSinceEpoch, gpsMessage: ready ? 'GPS SIAP' : 'Mencari GPS…'));
  }

  Future<void> stop() async {
    running = false;
    await _positionSub?.cancel();
    await _accSub?.cancel();
    _positionSub = null;
    _accSub = null;
    _last = null;
    _distanceM = 0;
  }

  void resetDistance() { _distanceM = 0; _last = null; }
  double get sensorMotion => _sensorMotion;
  Future<void> dispose() async { await stop(); await _controller.close(); await _positionController.close(); }
}

class TripRecorder {
  final StoreService store;
  final int id = DateTime.now().millisecondsSinceEpoch;
  final List<TripPoint> points = [];
  double distM = 0;
  double maxKmh = 0;
  int? lastSaveMs;
  TripRecorder(this.store);

  void addPosition(Position p) {
    if (p.accuracy > 30) return;
    final t = p.timestamp.millisecondsSinceEpoch;
    final point = TripPoint(t, p.latitude, p.longitude, p.altitude, math.max(0.0, p.speed * 3.6));
    final last = points.isEmpty ? null : points.last;
    if (last != null) {
      final d = Geolocator.distanceBetween(last.lat, last.lon, point.lat, point.lon);
      final dt = (point.t - last.t) / 1000.0;
      if (d < 4 && dt < 15) return;
      if (dt > 0 && d / dt > 100) return;
      distM += d;
    }
    points.add(point);
    if (point.speedKmh > maxKmh) maxKmh = point.speedKmh;
  }

  Future<void> save({String name = ''}) async {
    if (points.length < 2 || distM < 20) return;
    final duration = points.last.t - points.first.t;
    final avg = duration > 0 ? distM / (duration / 1000) * 3.6 : 0.0;
    await store.saveTrip(TripMeta(id: id, name: name, startMs: points.first.t, endMs: points.last.t, distM: distM, maxKmh: maxKmh, points: points.length, avgKmh: avg), points);
  }
}
