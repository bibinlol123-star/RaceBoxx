import 'dart:convert';

class SpeedSample {
  final double t;
  final double v;
  const SpeedSample(this.t, this.v);
  Map<String, dynamic> toJson() => {'t': t, 'v': v};
  factory SpeedSample.fromJson(Map<String, dynamic> j) => SpeedSample((j['t'] as num).toDouble(), (j['v'] as num).toDouble());
}

class SplitResult {
  final double t;
  final double v;
  const SplitResult(this.t, this.v);
  Map<String, dynamic> toJson() => {'t': t, 'v': v};
  factory SplitResult.fromJson(Map<String, dynamic> j) => SplitResult((j['t'] as num).toDouble(), (j['v'] as num).toDouble());
}

class RunRecord {
  final int id;
  final int dateMs;
  final Map<int, SplitResult> splits;
  final double maxSpeedKmh;
  final double? gpsAccuracyM;
  final List<SpeedSample> samples;
  final String vehicleName;
  final String kind;
  final double rangeFromKmh;
  final double rangeToKmh;
  final double? rangeTimeSec;
  final double? reactionSec;
  final double startSpeedKmh;

  const RunRecord({
    required this.id,
    required this.dateMs,
    required this.splits,
    required this.maxSpeedKmh,
    required this.gpsAccuracyM,
    required this.samples,
    this.vehicleName = '',
    this.kind = 'drag',
    this.rangeFromKmh = 0,
    this.rangeToKmh = 0,
    this.rangeTimeSec,
    this.reactionSec,
    this.startSpeedKmh = 0,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': dateMs,
        'splits': {for (final e in splits.entries) e.key.toString(): e.value.toJson()},
        'maxSpeedKmh': maxSpeedKmh,
        'gpsAccuracyM': gpsAccuracyM,
        'samples': samples.map((e) => e.toJson()).toList(),
        'vehicleName': vehicleName,
        'kind': kind,
        'rangeFromKmh': rangeFromKmh,
        'rangeToKmh': rangeToKmh,
        'rangeTimeSec': rangeTimeSec,
        'reactionSec': reactionSec,
        'startSpeedKmh': startSpeedKmh,
      };

  factory RunRecord.fromJson(Map<String, dynamic> j) => RunRecord(
        id: (j['id'] as num).toInt(),
        dateMs: (j['date'] as num).toInt(),
        splits: (j['splits'] as Map? ?? {}).map((k, v) => MapEntry(int.parse(k.toString()), SplitResult.fromJson(Map<String, dynamic>.from(v as Map)))),
        maxSpeedKmh: (j['maxSpeedKmh'] as num?)?.toDouble() ?? 0,
        gpsAccuracyM: (j['gpsAccuracyM'] as num?)?.toDouble(),
        samples: ((j['samples'] as List?) ?? []).map((e) => SpeedSample.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
        vehicleName: j['vehicleName']?.toString() ?? '',
        kind: j['kind']?.toString() ?? 'drag',
        rangeFromKmh: (j['rangeFromKmh'] as num?)?.toDouble() ?? 0,
        rangeToKmh: (j['rangeToKmh'] as num?)?.toDouble() ?? 0,
        rangeTimeSec: (j['rangeTimeSec'] as num?)?.toDouble(),
        reactionSec: (j['reactionSec'] as num?)?.toDouble(),
        startSpeedKmh: (j['startSpeedKmh'] as num?)?.toDouble() ?? 0,
      );
}

class Vehicle {
  int id;
  String name;
  double calPct;
  Vehicle(this.id, this.name, [this.calPct = 0]);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'calPct': calPct};
  factory Vehicle.fromJson(Map<String, dynamic> j) => Vehicle((j['id'] as num).toInt(), j['name']?.toString() ?? 'Kendaraan', (j['calPct'] as num?)?.toDouble() ?? 0);
}

class RaceTarget {
  double speedKmh;
  int j1;
  int j2;
  RaceTarget({this.speedKmh = 100, this.j1 = 201, this.j2 = 402});
  Map<String, dynamic> toJson() => {'speedKmh': speedKmh, 'j1': j1, 'j2': j2};
  factory RaceTarget.fromJson(Map<String, dynamic> j) => RaceTarget(speedKmh: (j['speedKmh'] as num?)?.toDouble() ?? 100, j1: (j['j1'] as num?)?.toInt() ?? 201, j2: (j['j2'] as num?)?.toInt() ?? 402);
}

class AppSettings {
  String unit;
  double calSpeedPct;
  double startThresholdKmh;
  List<int> dragTargets;
  RaceTarget raceTarget;
  String mountMode;
  List<Vehicle> vehicles;
  int activeVehicleId;
  bool keepScreenOn;
  bool keepAlive;
  double autoStopSec;
  bool reactionMode;
  double rollingStartKmh;
  double rangeFrom;
  double rangeTo;
  String accent;

  AppSettings({
    this.unit = 'kmh',
    this.calSpeedPct = 0,
    this.startThresholdKmh = 1.5,
    List<int>? dragTargets,
    RaceTarget? raceTarget,
    this.mountMode = 'fixed',
    List<Vehicle>? vehicles,
    this.activeVehicleId = 1,
    this.keepScreenOn = true,
    this.keepAlive = true,
    this.autoStopSec = 3,
    this.reactionMode = false,
    this.rollingStartKmh = 0,
    this.rangeFrom = 60,
    this.rangeTo = 130,
    this.accent = 'teal',
  })  : dragTargets = dragTargets ?? [20, 100, 201, 203],
        raceTarget = raceTarget ?? RaceTarget(),
        vehicles = vehicles ?? [Vehicle(1, 'Motor 1')];

  Vehicle get activeVehicle => vehicles.firstWhere((v) => v.id == activeVehicleId, orElse: () => vehicles.first);

  double displaySpeed(double kmh) => unit == 'kmh' ? kmh : kmh * 0.621371;
  String get unitStr => unit == 'kmh' ? 'km/h' : 'mph';

  Map<String, dynamic> toJson() => {
        'unit': unit,
        'calSpeedPct': calSpeedPct,
        'startThresholdKmh': startThresholdKmh,
        'dragTargets': dragTargets,
        'raceTarget': raceTarget.toJson(),
        'mountMode': mountMode,
        'vehicles': vehicles.map((e) => e.toJson()).toList(),
        'activeVehicleId': activeVehicleId,
        'keepScreenOn': keepScreenOn,
        'keepAlive': keepAlive,
        'autoStopSec': autoStopSec,
        'reactionMode': reactionMode,
        'rollingStartKmh': rollingStartKmh,
        'rangeFrom': rangeFrom,
        'rangeTo': rangeTo,
        'accent': accent,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        unit: j['unit']?.toString() ?? 'kmh',
        calSpeedPct: (j['calSpeedPct'] as num?)?.toDouble() ?? 0,
        startThresholdKmh: (j['startThresholdKmh'] as num?)?.toDouble() ?? 1.5,
        dragTargets: ((j['dragTargets'] as List?) ?? [20, 100, 201, 203]).map((e) => (e as num).toInt()).toList(),
        raceTarget: RaceTarget.fromJson(Map<String, dynamic>.from(j['raceTarget'] as Map? ?? {})),
        mountMode: j['mountMode']?.toString() ?? 'fixed',
        vehicles: ((j['vehicles'] as List?) ?? []).map((e) => Vehicle.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
        activeVehicleId: (j['activeVehicleId'] as num?)?.toInt() ?? 1,
        keepScreenOn: j['keepScreenOn'] as bool? ?? true,
        keepAlive: j['keepAlive'] as bool? ?? true,
        autoStopSec: (j['autoStopSec'] as num?)?.toDouble() ?? 3,
        reactionMode: j['reactionMode'] as bool? ?? false,
        rollingStartKmh: (j['rollingStartKmh'] as num?)?.toDouble() ?? 0,
        rangeFrom: (j['rangeFrom'] as num?)?.toDouble() ?? 60,
        rangeTo: (j['rangeTo'] as num?)?.toDouble() ?? 130,
        accent: j['accent']?.toString() ?? 'teal',
      ).._ensureVehicle();

  void _ensureVehicle() {
    if (vehicles.isEmpty) vehicles.add(Vehicle(1, 'Motor 1'));
    if (!vehicles.any((v) => v.id == activeVehicleId)) activeVehicleId = vehicles.first.id;
  }

  String encode() => jsonEncode(toJson());
  static AppSettings decode(String raw) => AppSettings.fromJson(jsonDecode(raw) as Map<String, dynamic>);
}

class MotionReading {
  final double speedKmh;
  final double distanceM;
  final double? gpsAccuracyM;
  final bool gpsFixOk;
  final bool gpsReady;
  final int timeMs;
  final String gpsMessage;
  const MotionReading({required this.speedKmh, required this.distanceM, required this.gpsAccuracyM, required this.gpsFixOk, required this.gpsReady, required this.timeMs, this.gpsMessage = ''});
}

class TripPoint {
  final int t;
  final double lat;
  final double lon;
  final double alt;
  final double speedKmh;
  const TripPoint(this.t, this.lat, this.lon, this.alt, this.speedKmh);
  List<dynamic> toJson() => [t, lat, lon, alt, speedKmh];
  factory TripPoint.fromJson(List<dynamic> j) => TripPoint((j[0] as num).toInt(), (j[1] as num).toDouble(), (j[2] as num).toDouble(), (j[3] as num).toDouble(), (j[4] as num).toDouble());
}

class TripMeta {
  final int id;
  final String name;
  final int startMs;
  final int endMs;
  final double distM;
  final double maxKmh;
  final int points;
  final double avgKmh;
  const TripMeta({required this.id, required this.name, required this.startMs, required this.endMs, required this.distM, required this.maxKmh, required this.points, this.avgKmh = 0});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'startMs': startMs, 'endMs': endMs, 'distM': distM, 'maxKmh': maxKmh, 'points': points, 'avgKmh': avgKmh};
  factory TripMeta.fromJson(Map<String, dynamic> j) => TripMeta(id: (j['id'] as num).toInt(), name: j['name']?.toString() ?? '', startMs: (j['startMs'] as num).toInt(), endMs: (j['endMs'] as num).toInt(), distM: (j['distM'] as num).toDouble(), maxKmh: (j['maxKmh'] as num).toDouble(), points: (j['points'] as num).toInt(), avgKmh: (j['avgKmh'] as num?)?.toDouble() ?? 0);
  Duration get duration => Duration(milliseconds: endMs - startMs);
}
