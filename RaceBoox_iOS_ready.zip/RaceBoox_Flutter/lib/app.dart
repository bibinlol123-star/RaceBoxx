import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'models.dart';
import 'services.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'theme.dart';
import 'widgets.dart';

late final StoreService store;
late final MotionService motion;
AppSettings settings = AppSettings();

Future<void> bootstrap() async {
  store = StoreService();
  await store.init();
  settings = store.loadSettings();
  motion = MotionService()
    ..calibrationPct = settings.activeVehicle.calPct
    ..mountInBag = settings.mountMode == 'bag';
}

MaterialPageRoute<T> page<T>(Widget child) => MaterialPageRoute(builder: (_) => child);

class RaceBooxApp extends StatefulWidget {
  const RaceBooxApp({super.key});
  @override State<RaceBooxApp> createState() => _RaceBooxAppState();
}

class _RaceBooxAppState extends State<RaceBooxApp> {
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'RaceBoox',
        theme: raceTheme(settings.accent),
        home: const SplashPage(),
      );
}

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override State<SplashPage> createState() => _SplashPageState();
}
class _SplashPageState extends State<SplashPage> {
  @override void initState() { super.initState(); Future.delayed(const Duration(milliseconds: 900), () { if (mounted) Navigator.of(context).pushReplacement(page(const HomePage())); }); }
  @override Widget build(BuildContext context) => Scaffold(body: CarbonBackground(child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [ClipRRect(borderRadius: BorderRadius.circular(28), child: Image.asset('assets/images/raceboox_logo.png', width: 92, height: 92)), const SizedBox(height: 16), const Text('RACEBOOX', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 7)), const SizedBox(height: 4), Text('GPS PERFORMANCE METER', style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.primary, letterSpacing: 2.5, fontWeight: FontWeight.w800)), const SizedBox(height: 24), SizedBox(width: 140, child: LinearProgressIndicator(minHeight: 3))]))));
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('RACEBOOX'), actions: [IconButton(onPressed: () => Navigator.push(context, page(const SettingsPage())), icon: const Icon(Icons.tune_rounded))]), body: CarbonBackground(child: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(18, 10, 18, 32), children: [
    Center(child: Column(children: [ClipRRect(borderRadius: BorderRadius.circular(22), child: Image.asset('assets/images/raceboox_logo.png', width: 78, height: 78)), const SizedBox(height: 8), const Text('RACEBOOX', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 5)), const SizedBox(height: 3), const Text('GPS PERFORMANCE METER', style: TextStyle(color: RaceColors.sub, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2.2)), const SizedBox(height: 24)])),
    MenuCard(icon: Icons.speed_rounded, title: 'Speedo Meter', subtitle: 'Kecepatan real-time & rekam trip', onTap: () => Navigator.push(context, page(const SpeedoPage()))),
    const SizedBox(height: 12),
    MenuCard(icon: Icons.motorcycle_rounded, title: 'Drag Meter', subtitle: 'Waktu 0–100, 201 m, reaction time', onTap: () => Navigator.push(context, page(const DragSetupPage()))),
    const SizedBox(height: 12),
    MenuCard(icon: Icons.history_rounded, title: 'History', subtitle: 'Riwayat run & rekor pribadi', onTap: () => Navigator.push(context, page(const HistoryPage()))),
    const SizedBox(height: 12),
    MenuCard(icon: Icons.swap_vert_circle_rounded, title: 'Tes Rentang', subtitle: 'Akselerasi dari kecepatan ke kecepatan', onTap: () => Navigator.push(context, page(const RangePage()))),
    const SizedBox(height: 12),
    MenuCard(icon: Icons.route_rounded, title: 'Trip', subtitle: 'Rekam rute GPS, jarak dan GPX', onTap: () => Navigator.push(context, page(const TripsPage()))),
  ]))));
}

class SpeedoPage extends StatefulWidget {
  const SpeedoPage({super.key});
  @override State<SpeedoPage> createState() => _SpeedoPageState();
}
class _SpeedoPageState extends State<SpeedoPage> {
  StreamSubscription<MotionReading>? sub;
  StreamSubscription? positionSub;
  double speed = 0, dist = 0, maxSpeed = 0;
  double? accuracy;
  List<double> samples = [];
  bool recording = false;
  TripRecorder? trip;
  DateTime? recordStart;
  ({double dist, int dur}) stats = (0, 0);

  @override void initState() { super.initState(); if (settings.keepScreenOn) WakelockPlus.enable(); _start(); }
  Future<void> _start() async {
    stats = store.todayStats();
    await motion.start();
    sub = motion.stream.listen((r) => setState(() { speed = r.speedKmh; dist = r.distanceM; accuracy = r.gpsAccuracyM; maxSpeed = maxSpeed < speed ? speed : maxSpeed; samples = [...samples.take(79), speed]; }));
    positionSub = motion.positions.listen((p) { if (recording) trip?.addPosition(p); });
  }
  void _toggleRecord() {
    if (recording) {
      trip?.save();
      final end = DateTime.now();
      final duration = recordStart == null ? 0 : end.difference(recordStart!).inMilliseconds;
      store.saveTodayStats(stats.dist + (trip?.distM ?? 0), stats.dur + duration);
      setState(() => recording = false);
    } else {
      trip = TripRecorder(store);
      recordStart = DateTime.now();
      setState(() => recording = true);
    }
  }
  @override void dispose() { sub?.cancel(); positionSub?.cancel(); WakelockPlus.disable(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('SPEEDO METER')), body: CarbonBackground(child: ListView(padding: const EdgeInsets.all(16), children: [
    RaceCard(child: Column(children: [Gauge(speed: settings.displaySpeed(speed), unit: settings.unitStr), Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.gps_fixed, color: accuracy != null && accuracy! <= 12 ? RaceColors.green : RaceColors.yellow, size: 16), const SizedBox(width: 6), Text(accuracy == null ? 'Mencari GPS…' : 'GPS ±${accuracy!.toStringAsFixed(0)} m', style: const TextStyle(color: RaceColors.sub, fontWeight: FontWeight.w700))]), const SizedBox(height: 18), Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: [StatChip(label: 'MAX', value: '${settings.displaySpeed(maxSpeed).toStringAsFixed(1)} ${settings.unitStr}'), StatChip(label: 'DIST', value: '${(dist / 1000).toStringAsFixed(2)} km')])])),
    const SizedBox(height: 12), RaceCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('LIVE GRAPH', style: TextStyle(color: RaceColors.sub, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)), const SizedBox(height: 12), SpeedGraph(values: samples.map(settings.displaySpeed).toList())])),
    const SizedBox(height: 12), RaceCard(child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('TRIP RECORDER', style: TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(recording ? 'Sedang merekam rute GPS' : 'Mulai merekam rute saat berkendara', style: const TextStyle(color: RaceColors.sub, fontSize: 12))])), FilledButton.icon(onPressed: _toggleRecord, icon: Icon(recording ? Icons.stop_rounded : Icons.fiber_manual_record_rounded), label: Text(recording ? 'STOP' : 'REC'))])),
    const SizedBox(height: 12), RaceCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('HARI INI', style: TextStyle(color: RaceColors.sub, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)), const SizedBox(height: 10), Text('${(stats.dist / 1000).toStringAsFixed(2)} km  •  ${_fmtDuration(stats.dur)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))]))
  ])));
}

class StatChip extends StatelessWidget { final String label, value; const StatChip({super.key, required this.label, required this.value}); @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: RaceColors.panel2, borderRadius: BorderRadius.circular(12), border: Border.all(color: RaceColors.border)), child: Column(children: [Text(label, style: const TextStyle(color: RaceColors.sub, fontSize: 9, fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800))])); }

class DragSetupPage extends StatefulWidget { const DragSetupPage({super.key}); @override State<DragSetupPage> createState() => _DragSetupPageState(); }
class _DragSetupPageState extends State<DragSetupPage> {
  late List<int> targets = [...settings.dragTargets];
  bool reaction = settings.reactionMode;
  double rolling = settings.rollingStartKmh;
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('DRAG SETUP')), body: CarbonBackground(child: ListView(padding: const EdgeInsets.all(16), children: [
    RaceCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('TARGET JARAK', style: TextStyle(color: RaceColors.sub, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)), const SizedBox(height: 12), Wrap(spacing: 8, runSpacing: 8, children: [20, 60, 100, 201, 203, 402].map((d) => FilterChip(label: Text('${d} m'), selected: targets.contains(d), onSelected: (v) => setState(() { v ? targets.add(d) : targets.remove(d); targets.sort(); }), selectedColor: Theme.of(context).colorScheme.primary.withOpacity(.22))).toList())])),
    const SizedBox(height: 12), RaceCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Reaction Mode', style: TextStyle(fontWeight: FontWeight.w800)), subtitle: const Text('Lampu start + reaction time', style: TextStyle(color: RaceColors.sub, fontSize: 12)), value: reaction, onChanged: (v) => setState(() => reaction = v)), const SizedBox(height: 6), Text('Rolling start: ${rolling.toStringAsFixed(0)} km/h', style: const TextStyle(fontWeight: FontWeight.w800)), Slider(value: rolling, min: 0, max: 30, divisions: 30, onChanged: (v) => setState(() => rolling = v)), const Text('0 = start dari diam', style: TextStyle(color: RaceColors.sub, fontSize: 11))])),
    const SizedBox(height: 12), FilledButton.icon(onPressed: () { settings.dragTargets = targets.isEmpty ? [20, 100, 201, 203] : targets; settings.reactionMode = reaction; settings.rollingStartKmh = rolling; store.saveSettings(settings); Navigator.push(context, page(const DragRunPage())); }, icon: const Icon(Icons.play_arrow_rounded), label: const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Text('MULAI DRAG')))
  ])));
}

class DragRunPage extends StatefulWidget { const DragRunPage({super.key}); @override State<DragRunPage> createState() => _DragRunPageState(); }
class _DragRunPageState extends State<DragRunPage> {
  StreamSubscription<MotionReading>? sub;
  String phase = 'WAITING GPS';
  double speed = 0, startDist = 0, maxSpeed = 0;
  int? startMs;
  final splits = <int, SplitResult>{};
  final samples = <SpeedSample>[];
  DateTime? stillSince;
  bool finished = false;
  int lightStep = 0;
  bool green = false;
  int? greenMs;
  double? reactionSec;
  Timer? countdown;
  @override void initState() { super.initState(); if (settings.keepScreenOn) WakelockPlus.enable(); _boot(); }
  Future<void> _boot() async { await motion.start(); sub = motion.stream.listen(_on); }
  void _on(MotionReading r) {
    if (!mounted || finished) return;
    setState(() { speed = r.speedKmh; maxSpeed = math.max(maxSpeed, speed); });
    if (phase == 'WAITING GPS' && r.gpsReady) { setState(() => phase = 'ARMED'); if (settings.reactionMode) _readyLights(); return; }
    if (phase == 'ARMED') {
      if (settings.reactionMode && green && r.speedKmh >= settings.startThresholdKmh) { _begin(r); return; }
      if (settings.rollingStartKmh > 0 && r.speedKmh >= settings.rollingStartKmh) { _begin(r); return; }
      if (settings.rollingStartKmh <= 0 && !settings.reactionMode && r.speedKmh >= settings.startThresholdKmh) { _begin(r); return; }
    }
    if (phase == 'RUNNING') {
      final elapsed = ((r.timeMs - (startMs ?? r.timeMs)) / 1000).clamp(0, 9999).toDouble();
      final d = math.max(0, r.distanceM - startDist);
      samples.add(SpeedSample(elapsed, r.speedKmh));
      for (final target in settings.dragTargets) {
        if (!splits.containsKey(target) && d >= target) splits[target] = SplitResult(elapsed, r.speedKmh);
      }
      final stop = settings.autoStopSec;
      if (maxSpeed >= 10 && speed < 1) { stillSince ??= DateTime.now(); if (DateTime.now().difference(stillSince!).inMilliseconds >= stop * 1000) { _finish(); return; } } else stillSince = null;
      if (settings.dragTargets.every(splits.containsKey)) _finish();
    }
  }
  void _readyLights() { countdown?.cancel(); lightStep = 1; setState(() {}); countdown = Timer.periodic(const Duration(milliseconds: 550), (t) { if (!mounted) return; if (lightStep < 3) { setState(() => lightStep++); } else { t.cancel(); green = true; greenMs = DateTime.now().millisecondsSinceEpoch; setState(() {}); }}); }
  void _begin(MotionReading r) { startMs = r.timeMs; startDist = r.distanceM; phase = 'RUNNING'; if (settings.reactionMode && green && greenMs != null) reactionSec = (DateTime.now().millisecondsSinceEpoch - greenMs!) / 1000.0; setState(() {}); }
  Future<void> _finish() async { if (finished) return; finished = true; countdown?.cancel(); final eligible = phase == 'RUNNING' && (splits.isNotEmpty || samples.length > 3); if (eligible) { final id = DateTime.now().millisecondsSinceEpoch; await store.addRun(RunRecord(id: id, dateMs: id, splits: Map.of(splits), maxSpeedKmh: maxSpeed, gpsAccuracyM: null, samples: List.of(samples), vehicleName: settings.activeVehicle.name, kind: 'drag', reactionSec: reactionSec, startSpeedKmh: settings.rollingStartKmh)); } if (mounted) { await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Run selesai'), content: Text('Max ${settings.displaySpeed(maxSpeed).toStringAsFixed(1)} ${settings.unitStr}\n${splits.entries.map((e) => '${e.key} m: ${e.value.t.toStringAsFixed(3)} s').join('\n')}'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('TUTUP'))])); Navigator.pop(context); } }
  @override void dispose() { countdown?.cancel(); sub?.cancel(); WakelockPlus.disable(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('DRAG METER')), body: CarbonBackground(child: ListView(padding: const EdgeInsets.all(16), children: [RaceCard(child: Column(children: [Text(phase, style: TextStyle(color: phase == 'RUNNING' ? RaceColors.green : Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w900, letterSpacing: 2)), const SizedBox(height: 6), Text(settings.displaySpeed(speed).toStringAsFixed(1), style: const TextStyle(fontSize: 72, fontWeight: FontWeight.w900)), Text(settings.unitStr, style: const TextStyle(color: RaceColors.sub, letterSpacing: 2, fontWeight: FontWeight.bold)), const SizedBox(height: 16), if (settings.reactionMode) ReactionLights(step: lightStep, green: green), const SizedBox(height: 18), ...settings.dragTargets.map((d) => _SplitRow(d, splits[d], accent: Theme.of(context).colorScheme.primary)), const SizedBox(height: 16), FilledButton.icon(onPressed: phase == 'ARMED' && settings.reactionMode && !green ? null : _finish, icon: const Icon(Icons.stop_rounded), label: const Text('STOP / SIMPAN'))]))]));
}
class _SplitRow extends StatelessWidget { final int d; final SplitResult? result; final Color accent; const _SplitRow(this.d, this.result, {required this.accent}); @override Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 7), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), decoration: BoxDecoration(color: RaceColors.panel2, borderRadius: BorderRadius.circular(10)), child: Row(children: [Text('$d m', style: const TextStyle(fontWeight: FontWeight.w800)), const Spacer(), Text(result == null ? '--' : '${result!.t.toStringAsFixed(3)} s', style: TextStyle(color: result == null ? RaceColors.sub : accent, fontWeight: FontWeight.w900))])); }
class ReactionLights extends StatelessWidget { final int step; final bool green; const ReactionLights({super.key, required this.step, required this.green}); @override Widget build(BuildContext context) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [1, 2, 3].map((i) => Container(width: 28, height: 28, margin: const EdgeInsets.symmetric(horizontal: 5), decoration: BoxDecoration(shape: BoxShape.circle, color: green ? Colors.greenAccent : (step >= i ? RaceColors.yellow : RaceColors.panel2), border: Border.all(color: RaceColors.border, width: 2))).toList()); }

class RangePage extends StatefulWidget { const RangePage({super.key}); @override State<RangePage> createState() => _RangePageState(); }
class _RangePageState extends State<RangePage> {
  StreamSubscription<MotionReading>? sub;
  double speed = 0, timer = 0;
  bool running = false, done = false;
  int? startMs;
  final froms = [40.0, 60.0, 80.0, 100.0];
  final tos = [80.0, 100.0, 120.0, 130.0, 160.0];
  late double from = settings.rangeFrom, to = settings.rangeTo;
  @override void initState() { super.initState(); if (settings.keepScreenOn) WakelockPlus.enable(); _boot(); }
  Future<void> _boot() async { await motion.start(); sub = motion.stream.listen(_on); }
  void _on(MotionReading r) { if (!mounted || done) return; setState(() { speed = r.speedKmh; if (running && startMs != null) timer = (r.timeMs - startMs!) / 1000; }); if (!running && speed >= from) { setState(() { running = true; startMs = r.timeMs; timer = 0; }); } else if (running && speed >= to) { _finish(r); } }
  Future<void> _finish(MotionReading r) async { done = true; final id = DateTime.now().millisecondsSinceEpoch; await store.addRun(RunRecord(id: id, dateMs: id, splits: {}, maxSpeedKmh: r.speedKmh, gpsAccuracyM: null, samples: [SpeedSample(0, from), SpeedSample(timer, r.speedKmh)], vehicleName: settings.activeVehicle.name, kind: 'range', rangeFromKmh: from, rangeToKmh: to, rangeTimeSec: timer)); if (mounted) await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Tes selesai'), content: Text('${from.toStringAsFixed(0)} → ${to.toStringAsFixed(0)} km/h\n${timer.toStringAsFixed(3)} detik'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))])); if (mounted) Navigator.pop(context); }
  @override void dispose() { sub?.cancel(); positionSub?.cancel(); WakelockPlus.disable(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('TES RENTANG')), body: CarbonBackground(child: ListView(padding: const EdgeInsets.all(16), children: [RaceCard(child: Column(children: [Text(settings.displaySpeed(speed).toStringAsFixed(1), style: const TextStyle(fontSize: 72, fontWeight: FontWeight.w900)), Text(settings.unitStr, style: const TextStyle(color: RaceColors.sub, fontWeight: FontWeight.bold, letterSpacing: 2)), const SizedBox(height: 20), const Align(alignment: Alignment.centerLeft, child: Text('DARI', style: TextStyle(color: RaceColors.sub, fontSize: 11, fontWeight: FontWeight.w900))), const SizedBox(height: 8), Wrap(spacing: 8, children: froms.map((v) => ChoiceChip(label: Text('${v.toInt()}'), selected: from == v, onSelected: (_) => setState(() => from = v))).toList()), const SizedBox(height: 16), const Align(alignment: Alignment.centerLeft, child: Text('KE', style: TextStyle(color: RaceColors.sub, fontSize: 11, fontWeight: FontWeight.w900))), const SizedBox(height: 8), Wrap(spacing: 8, children: tos.map((v) => ChoiceChip(label: Text('${v.toInt()}'), selected: to == v, onSelected: (_) => setState(() => to = v))).toList()), const SizedBox(height: 22), Container(width: double.infinity, padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: RaceColors.panel2, borderRadius: BorderRadius.circular(14)), child: Column(children: [Text('${from.toStringAsFixed(0)} → ${to.toStringAsFixed(0)} km/h', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(timer.toStringAsFixed(2), style: const TextStyle(fontSize: 54, fontWeight: FontWeight.w900)), const Text('detik', style: TextStyle(color: RaceColors.sub))]),)]))])));
}

class HistoryPage extends StatefulWidget { const HistoryPage({super.key}); @override State<HistoryPage> createState() => _HistoryPageState(); }
class _HistoryPageState extends State<HistoryPage> {
  List<RunRecord> data = [];
  @override void initState() { super.initState(); _load(); }
  void _load() => setState(() => data = store.loadHistory());
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('HISTORY'), actions: [
    IconButton(onPressed: data.length < 2 ? null : () => Navigator.push(context, page(ComparePage(a: data[0], b: data[1]))), icon: const Icon(Icons.compare_arrows_rounded)),
    IconButton(onPressed: data.isEmpty ? null : () async { await store.exportCsv(data, settings.dragTargets); }, icon: const Icon(Icons.ios_share_rounded)),
  ]), body: CarbonBackground(child: data.isEmpty ? const Center(child: Text('🏁\nBelum ada riwayat run.', textAlign: TextAlign.center, style: TextStyle(color: RaceColors.sub, fontSize: 16))) : ListView.builder(padding: const EdgeInsets.all(16), itemCount: data.length, itemBuilder: (_, i) { final r = data[i]; return Padding(padding: const EdgeInsets.only(bottom: 10), child: Dismissible(key: ValueKey(r.id), background: Container(decoration: BoxDecoration(color: RaceColors.red, borderRadius: BorderRadius.circular(16)), alignment: Alignment.centerLeft, padding: const EdgeInsets.all(20), child: const Icon(Icons.delete_outline)), secondaryBackground: Container(decoration: BoxDecoration(color: RaceColors.red, borderRadius: BorderRadius.circular(16)), alignment: Alignment.centerRight, padding: const EdgeInsets.all(20), child: const Icon(Icons.delete_outline)), confirmDismiss: (_) async { return await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Hapus run?'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus'))])); }, onDismissed: (_) async { await store.deleteRun(r.id); _load(); }, child: InkWell(onTap: () => Navigator.push(context, page(HistoryDetailPage(run: r))).then((_) => _load()), child: RaceCard(child: Row(children: [Container(width: 10, height: 44, decoration: BoxDecoration(color: r.kind == 'range' ? RaceColors.orange : Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(8))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r.kind == 'range' ? '${r.rangeFromKmh.toStringAsFixed(0)} → ${r.rangeToKmh.toStringAsFixed(0)} km/h' : '${r.splits.entries.isEmpty ? 'Drag Run' : r.splits.entries.map((e) => '${e.key}m').join('  ')}', style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text('${DateTime.fromMillisecondsSinceEpoch(r.dateMs)}  •  ${r.vehicleName}', style: const TextStyle(color: RaceColors.sub, fontSize: 11))])), Text('${settings.displaySpeed(r.maxSpeedKmh).toStringAsFixed(0)}\n${settings.unitStr}', textAlign: TextAlign.right, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900))]))))); }));
}

class HistoryDetailPage extends StatelessWidget { final RunRecord run; const HistoryDetailPage({super.key, required this.run}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('DETAIL RUN')), body: CarbonBackground(child: ListView(padding: const EdgeInsets.all(16), children: [RaceCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(run.kind == 'range' ? 'TES RENTANG' : 'DRAG METER', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w900, letterSpacing: 1.4)), const SizedBox(height: 6), Text(run.vehicleName.isEmpty ? 'Kendaraan' : run.vehicleName, style: const TextStyle(color: RaceColors.sub)), const SizedBox(height: 18), Row(children: [Expanded(child: StatBox('TOP SPEED', '${settings.displaySpeed(run.maxSpeedKmh).toStringAsFixed(1)} ${settings.unitStr}')), Expanded(child: StatBox('REACTION', run.reactionSec == null ? '-' : '${run.reactionSec!.toStringAsFixed(3)} s'))]), const SizedBox(height: 14), if (run.kind == 'range') StatBox('RANGE TIME', '${run.rangeTimeSec?.toStringAsFixed(3) ?? '-'} s'), if (run.kind != 'range') ...run.splits.entries.map((e) => Padding(padding: const EdgeInsets.only(top: 8), child: _SplitRow(e.key, e.value, accent: Theme.of(context).colorScheme.primary)))])), const SizedBox(height: 12), if (run.samples.length > 1) RaceCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('SPEED GRAPH', style: TextStyle(color: RaceColors.sub, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)), const SizedBox(height: 12), SpeedGraph(values: run.samples.map((e) => settings.displaySpeed(e.v)).toList())]))])); }
class StatBox extends StatelessWidget { final String a,b; const StatBox(this.a,this.b,{super.key}); @override Widget build(BuildContext context)=>Container(margin: const EdgeInsets.only(right: 8), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: RaceColors.panel2,borderRadius:BorderRadius.circular(12)), child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:RaceColors.sub,fontSize:9,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text(b,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900))])); }

class TripsPage extends StatefulWidget { const TripsPage({super.key}); @override State<TripsPage> createState() => _TripsPageState(); }
class _TripsPageState extends State<TripsPage> { List<TripMeta> trips=[]; @override void initState(){super.initState();_load();} void _load()=>setState(()=>trips=store.loadTrips()); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('TRIP')),body:CarbonBackground(child:trips.isEmpty?const Center(child:Text('Belum ada trip tersimpan.',style:TextStyle(color:RaceColors.sub))):ListView.builder(padding:const EdgeInsets.all(16),itemCount:trips.length,itemBuilder:(_,i){final t=trips[i];return Padding(padding:const EdgeInsets.only(bottom:10),child:InkWell(onTap:()=>Navigator.push(c,page(TripDetailPage(meta:t))).then((_){_load();}),child:RaceCard(child:Row(children:[const Icon(Icons.route_rounded,size:30),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${(t.distM/1000).toStringAsFixed(2)} km',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text('${DateTime.fromMillisecondsSinceEpoch(t.startMs)} • maks ${settings.displaySpeed(t.maxKmh).toStringAsFixed(0)} ${settings.unitStr}',style:const TextStyle(color:RaceColors.sub,fontSize:11))])),const Icon(Icons.chevron_right_rounded,color:RaceColors.sub)]))));})); }
}

class TripDetailPage extends StatefulWidget { final TripMeta meta; const TripDetailPage({super.key,required this.meta}); @override State<TripDetailPage> createState()=>_TripDetailPageState(); }
class _TripDetailPageState extends State<TripDetailPage>{late List<TripPoint> pts; @override void initState(){super.initState();pts=store.loadTripPoints(widget.meta.id);} @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('DETAIL TRIP')),body:CarbonBackground(child:ListView(padding:const EdgeInsets.all(16),children:[RaceCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(DateTime.fromMillisecondsSinceEpoch(widget.meta.startMs).toString(),style:const TextStyle(color:RaceColors.sub)),const SizedBox(height:14),Row(children:[Expanded(child:StatBox('DISTANCE','${(widget.meta.distM/1000).toStringAsFixed(2)} km')),Expanded(child:StatBox('MAX','${settings.displaySpeed(widget.meta.maxKmh).toStringAsFixed(1)} ${settings.unitStr}'))]),const SizedBox(height:12),StatBox('AVG','${settings.displaySpeed(widget.meta.avgKmh).toStringAsFixed(1)} ${settings.unitStr}')])) ,const SizedBox(height:12),RaceCard(child:RoutePreview(points:pts.map((e)=>(lat:e.lat,lon:e.lon)).toList())),const SizedBox(height:12),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:pts.isEmpty?null:()=>store.exportGpx(widget.meta,pts),icon:const Icon(Icons.share_rounded),label:const Text('EXPORT GPX'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:()async{await store.deleteTrip(widget.meta.id);if(mounted)Navigator.pop(c);},icon:const Icon(Icons.delete_outline),label:const Text('HAPUS')))])]));}
}

class ComparePage extends StatelessWidget {
  final RunRecord a, b;
  const ComparePage({super.key, required this.a, required this.b});
  @override
  Widget build(BuildContext c) {
    final ds = {...a.splits.keys, ...b.splits.keys}.toList()..sort();
    return Scaffold(
      appBar: AppBar(title: const Text('COMPARE')),
      body: CarbonBackground(child: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: StatBox('RUN A', '${settings.displaySpeed(a.maxSpeedKmh).toStringAsFixed(1)} ${settings.unitStr}')),
          Expanded(child: StatBox('RUN B', '${settings.displaySpeed(b.maxSpeedKmh).toStringAsFixed(1)} ${settings.unitStr}')),
        ]),
        const SizedBox(height: 12),
        RaceCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('SELISIH PER SPLIT', style: TextStyle(color: RaceColors.sub, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          const SizedBox(height: 12),
          ...ds.map((d) {
            final ta = a.splits[d]?.t;
            final tb = b.splits[d]?.t;
            final diff = ta != null && tb != null ? tb - ta : null;
            return Padding(padding: const EdgeInsets.only(bottom: 10), child: Row(children: [
              SizedBox(width: 65, child: Text('$d m', style: const TextStyle(fontWeight: FontWeight.w800))),
              Expanded(child: Text(ta == null ? '-' : 'A ${ta.toStringAsFixed(3)}s')),
              Expanded(child: Text(tb == null ? '-' : 'B ${tb.toStringAsFixed(3)}s')),
              Text(diff == null ? '-' : '${diff >= 0 ? '+' : ''}${diff.toStringAsFixed(3)}s', style: TextStyle(color: diff == null ? RaceColors.sub : (diff <= 0 ? RaceColors.green : RaceColors.red), fontWeight: FontWeight.w900)),
            ]));
          }),
        ])),
      ])),
    );
  }
}

class SettingsPage extends StatefulWidget { const SettingsPage({super.key}); @override State<SettingsPage> createState()=>_SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage> {
  late String unit,mount,accent; late double threshold,rolling,autoStop; late bool reaction,keepScreen,keepAlive; late List<Vehicle> vehicles; late int activeId;
  @override void initState(){super.initState();unit=settings.unit;mount=settings.mountMode;accent=settings.accent;threshold=settings.startThresholdKmh;rolling=settings.rollingStartKmh;autoStop=settings.autoStopSec;reaction=settings.reactionMode;keepScreen=settings.keepScreenOn;keepAlive=settings.keepAlive;vehicles=settings.vehicles.map((e)=>Vehicle(e.id,e.name,e.calPct)).toList();activeId=settings.activeVehicleId;}
  Vehicle get active=>vehicles.firstWhere((e)=>e.id==activeId);
  Future<void> _save() async { settings.unit=unit;settings.mountMode=mount;settings.accent=accent;settings.startThresholdKmh=threshold;settings.rollingStartKmh=rolling;settings.autoStopSec=autoStop;settings.reactionMode=reaction;settings.keepScreenOn=keepScreen;settings.keepAlive=keepAlive;settings.vehicles=vehicles;settings.activeVehicleId=activeId;motion.calibrationPct=active.calPct;motion.mountInBag=mount=='bag';await store.saveSettings(settings);if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Pengaturan disimpan')));}} 
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('SETTINGS')),body:CarbonBackground(child:ListView(padding:const EdgeInsets.all(16),children:[RaceCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('UNIT',style:TextStyle(color:RaceColors.sub,fontSize:11,fontWeight:FontWeight.w900)),const SizedBox(height:8),SegmentedButton<String>(segments:const [ButtonSegment(value:'kmh',label:Text('km/h')),ButtonSegment(value:'mph',label:Text('mph'))],selected:{unit},onSelectionChanged:(v)=>setState(()=>unit=v.first))])),const SizedBox(height:12),RaceCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('MOUNT MODE',style:TextStyle(color:RaceColors.sub,fontSize:11,fontWeight:FontWeight.w900)),const SizedBox(height:8),SegmentedButton<String>(segments:const [ButtonSegment(value:'fixed',label:Text('Fixed / Mount')),ButtonSegment(value:'bag',label:Text('Tas / Saku'))],selected:{mount},onSelectionChanged:(v)=>setState(()=>mount=v.first))])),const SizedBox(height:12),RaceCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('ACCENT',style:TextStyle(color:RaceColors.sub,fontSize:11,fontWeight:FontWeight.w900)),const SizedBox(height:12),Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:['teal','red','orange','purple'].map((k)=>InkWell(onTap:()=>setState(()=>accent=k),child:Column(children:[Container(width:42,height:42,decoration:BoxDecoration(color:RaceColors.accent(k),shape:BoxShape.circle,border:Border.all(color:accent==k?Colors.white:Colors.transparent,width:3))),const SizedBox(height:4),Text(k,style:TextStyle(fontSize:10,color:accent==k?Colors.white:RaceColors.sub))]))).toList())])),const SizedBox(height:12),RaceCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('KENDARAAN',style:TextStyle(color:RaceColors.sub,fontSize:11,fontWeight:FontWeight.w900)),const SizedBox(height:8),DropdownButtonFormField<int>(value:activeId,items:vehicles.map((v)=>DropdownMenuItem(value:v.id,child:Text(v.name))).toList(),onChanged:(v)=>setState(()=>activeId=v!),decoration:const InputDecoration(filled:true,border:OutlineInputBorder()),),const SizedBox(height:8),Text('Kalibrasi: ${active.calPct.toStringAsFixed(1)}%',style:const TextStyle(fontWeight:FontWeight.w800)),Slider(value:active.calPct.clamp(-20,20).toDouble(),min:-20,max:20,divisions:80,onChanged:(v)=>setState(()=>active.calPct=v)),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:_addVehicle,icon:const Icon(Icons.add),label:const Text('Tambah'))),const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:_renameVehicle,icon:const Icon(Icons.edit_outlined),label:const Text('Rename'))),const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:vehicles.length==1?null:_deleteVehicle,icon:const Icon(Icons.delete_outline),label:const Text('Hapus')))])])),const SizedBox(height:12),RaceCard(child:Column(children:[_numberSlider('Start threshold',threshold,0.5,5,0.5,(v)=>setState(()=>threshold=v)),_numberSlider('Rolling start',rolling,0,30,1,(v)=>setState(()=>rolling=v)),_numberSlider('Auto stop',autoStop,0,10,0.5,(v)=>setState(()=>autoStop=v)),SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Reaction mode'),value:reaction,onChanged:(v)=>setState(()=>reaction=v)),SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Keep screen on'),value:keepScreen,onChanged:(v)=>setState(()=>keepScreen=v)),SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Background tracking intent (OS-dependent)'),value:keepAlive,onChanged:(v)=>setState(()=>keepAlive=v))])),const SizedBox(height:12),FilledButton(onPressed:_save,child:const Padding(padding:EdgeInsets.symmetric(vertical:14),child:Text('SIMPAN PENGATURAN'))])));
  Widget _numberSlider(String name,double value,double min,double max,double step,ValueChanged<double> onChanged)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('$name: ${value.toStringAsFixed(step<1?1:0)}',style:const TextStyle(fontWeight:FontWeight.w800)),Slider(value:value.clamp(min,max).toDouble(),min:min,max:max,divisions:((max-min)/step).round(),onChanged:onChanged)]);
  void _addVehicle() { final id=DateTime.now().millisecondsSinceEpoch; setState((){vehicles.add(Vehicle(id,'Motor ${vehicles.length+1}'));activeId=id;}); }
  void _renameVehicle() { final ctl=TextEditingController(text:active.name); showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Ganti nama'),content:TextField(controller:ctl,autofocus:true),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Batal')),TextButton(onPressed:(){setState(()=>active.name=ctl.text.trim().isEmpty?active.name:ctl.text.trim());Navigator.pop(context);},child:const Text('OK'))])); }
  void _deleteVehicle(){final old=active;setState((){vehicles.remove(old);activeId=vehicles.first.id;});}
}

String _fmtDuration(int ms) { final sec = ms ~/ 1000; return "${sec ~/ 3600}:${((sec % 3600) ~/ 60).toString().padLeft(2, '0')}:${(sec % 60).toString().padLeft(2, '0')}"; }
