import 'package:flutter/material.dart';

class RaceColors {
  static const bg = Color(0xFF000000);
  static const panel = Color(0xFF0E1113);
  static const panel2 = Color(0xFF181C1F);
  static const sub = Color(0xFF8A919C);
  static const border = Color(0xFF242A2E);
  static const green = Color(0xFF2ECC71);
  static const yellow = Color(0xFFF5C518);
  static const gold = Color(0xFFFFC947);
  static const white = Color(0xFFFFFFFF);
  static const red = Color(0xFFFF453A);
  static const orange = Color(0xFFFF9F0A);
  static const purple = Color(0xFFA56BFF);
  static const teal = Color(0xFF3EE6D8);

  static Color accent(String key) => switch (key) { 'red' => red, 'orange' => orange, 'purple' => purple, _ => teal };
}

ThemeData raceTheme(String accentKey) {
  final accent = RaceColors.accent(accentKey);
  final scheme = ColorScheme.dark(primary: accent, secondary: accent, surface: RaceColors.panel, onSurface: Colors.white);
  return ThemeData(
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: RaceColors.bg,
    fontFamily: 'Roboto',
    useMaterial3: true,
    appBarTheme: AppBarTheme(backgroundColor: const Color(0xFF070A0C), foregroundColor: Colors.white, elevation: 0, centerTitle: false, titleTextStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: 2.0), iconTheme: IconThemeData(color: accent)),
    cardColor: RaceColors.panel,
    dividerColor: RaceColors.border,
    sliderTheme: SliderThemeData(activeTrackColor: accent, thumbColor: accent, inactiveTrackColor: RaceColors.border, overlayColor: accent.withOpacity(.15)),
    switchTheme: SwitchThemeData(thumbColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? accent : RaceColors.sub), trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? accent.withOpacity(.35) : RaceColors.panel2)),
  );
}
