import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'theme.dart';

class CarbonBackground extends StatelessWidget {
  final Widget child;
  const CarbonBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: const BoxDecoration(color: RaceColors.bg, image: DecorationImage(image: AssetImage('assets/images/carbon_tile.png'), repeat: ImageRepeat.repeat, opacity: .22)),
        child: child,
      );
}

class RaceCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;
  const RaceCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.borderColor});
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(color: RaceColors.panel.withOpacity(.94), borderRadius: BorderRadius.circular(16), border: Border.all(color: borderColor ?? RaceColors.border), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.35), blurRadius: 22, offset: const Offset(0, 8))]),
        padding: padding,
        child: child,
      );
}

class MenuCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const MenuCard({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.primary;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: RaceCard(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          Container(width: 54, height: 54, decoration: BoxDecoration(color: accent.withOpacity(.08), borderRadius: BorderRadius.circular(15), border: Border.all(color: accent.withOpacity(.18))), child: Icon(icon, color: accent, size: 28)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: RaceColors.sub, fontSize: 12))])),
          const Icon(Icons.chevron_right_rounded, color: RaceColors.sub),
        ]),
      ),
    );
  }
}

class Gauge extends StatelessWidget {
  final double speed;
  final double max;
  final String unit;
  const Gauge({super.key, required this.speed, required this.unit, this.max = 240});
  @override
  Widget build(BuildContext context) => SizedBox(height: 300, width: 300, child: CustomPaint(painter: _GaugePainter(speed: speed, max: max, accent: Theme.of(context).colorScheme.primary), child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text(speed.toStringAsFixed(1), style: const TextStyle(fontSize: 64, fontWeight: FontWeight.w900, height: .95, )), Text(unit, style: const TextStyle(color: RaceColors.sub, fontSize: 14, fontWeight: FontWeight.w800, letterSpacing: 2))]))));
}

class _GaugePainter extends CustomPainter {
  final double speed, max;
  final Color accent;
  _GaugePainter({required this.speed, required this.max, required this.accent});
  @override
  void paint(Canvas c, Size s) {
    final center = Offset(s.width / 2, s.height / 2);
    final r = math.min(s.width, s.height) / 2 - 18;
    final base = Paint()..style = PaintingStyle.stroke..strokeWidth = 10..strokeCap = StrokeCap.round..color = RaceColors.panel2;
    final value = Paint()..style = PaintingStyle.stroke..strokeWidth = 10..strokeCap = StrokeCap.round..color = accent;
    const start = 2.45;
    const sweep = 4.28;
    c.drawArc(Rect.fromCircle(center: center, radius: r), start, sweep, false, base);
    c.drawArc(Rect.fromCircle(center: center, radius: r), start, sweep * (speed / max).clamp(0, 1).toDouble(), false, value);
    final tick = Paint()..strokeWidth = 2..color = accent.withOpacity(.55);
    for (var i = 0; i <= 12; i++) {
      final a = start + sweep * i / 12;
      final p1 = Offset(center.dx + math.cos(a) * (r - 18), center.dy + math.sin(a) * (r - 18));
      final p2 = Offset(center.dx + math.cos(a) * (r + 2), center.dy + math.sin(a) * (r + 2));
      c.drawLine(p1, p2, tick);
    }
  }
  @override bool shouldRepaint(covariant _GaugePainter old) => old.speed != speed || old.accent != accent;
}

class SpeedGraph extends StatelessWidget {
  final List<double> values;
  final Color? color;
  const SpeedGraph({super.key, required this.values, this.color});
  @override
  Widget build(BuildContext context) => SizedBox(height: 180, child: CustomPaint(painter: _GraphPainter(values, color ?? Theme.of(context).colorScheme.primary)));
}

class _GraphPainter extends CustomPainter {
  final List<double> values;
  final Color color;
  _GraphPainter(this.values, this.color);
  @override
  void paint(Canvas c, Size s) {
    if (values.length < 2) return;
    final maxV = math.max(1.0, values.reduce(math.max));
    final line = Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = color;
    final fill = Paint()..style = PaintingStyle.fill..color = color.withOpacity(.08);
    final p = Path();
    for (var i = 0; i < values.length; i++) {
      final x = i * s.width / (values.length - 1);
      final y = s.height - values[i] / maxV * (s.height - 12) - 6;
      if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
    }
    final area = Path.from(p)..lineTo(s.width, s.height)..lineTo(0, s.height)..close();
    c.drawPath(area, fill);
    c.drawPath(p, line);
  }
  @override bool shouldRepaint(covariant _GraphPainter old) => old.values != values || old.color != color;
}

class RoutePreview extends StatelessWidget {
  final List<({double lat, double lon})> points;
  const RoutePreview({super.key, required this.points});
  @override
  Widget build(BuildContext context) => SizedBox(height: 280, child: CustomPaint(painter: _RoutePainter(points, Theme.of(context).colorScheme.primary)));
}

class _RoutePainter extends CustomPainter {
  final List<({double lat, double lon})> pts;
  final Color color;
  _RoutePainter(this.pts, this.color);
  @override
  void paint(Canvas c, Size s) {
    c.drawRect(Offset.zero & s, Paint()..color = RaceColors.panel2);
    if (pts.length < 2) return;
    final minLat = pts.map((e) => e.lat).reduce(math.min), maxLat = pts.map((e) => e.lat).reduce(math.max);
    final minLon = pts.map((e) => e.lon).reduce(math.min), maxLon = pts.map((e) => e.lon).reduce(math.max);
    final w = math.max(.00001, maxLon - minLon), h = math.max(.00001, maxLat - minLat);
    final path = Path();
    for (var i = 0; i < pts.length; i++) {
      final x = 14 + (pts[i].lon - minLon) / w * (s.width - 28);
      final y = s.height - 14 - (pts[i].lat - minLat) / h * (s.height - 28);
      if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
    }
    c.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = 4..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round..color = color);
    final first = path.getBounds().topLeft;
    c.drawCircle(first, 5, Paint()..color = Colors.white);
  }
  @override bool shouldRepaint(covariant _RoutePainter old) => old.pts.length != pts.length || old.color != color;
}
