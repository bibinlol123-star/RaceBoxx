#!/bin/sh
set -eu

cd "$(dirname "$0")/.."

echo "== RaceBoox iOS preparation =="
if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK tidak ditemukan. Jalankan ini di macOS yang sudah memasang Flutter + Xcode."
  exit 1
fi

flutter --version
flutter clean
flutter pub get

# Regenerate the complete official iOS/Xcode platform files.
rm -rf ios
flutter create --platforms=ios .

# Re-apply RaceBoox-specific iOS settings/permissions.
python3 tool/patch_ios.py

flutter pub get

echo
echo "iOS project siap."
echo "Untuk testing di iPhone:"
echo "  open ios/Runner.xcworkspace"
echo "atau:"
echo "  flutter run -d ios"
echo
echo "Untuk release IPA setelah signing:"
echo "  flutter build ipa --release"
