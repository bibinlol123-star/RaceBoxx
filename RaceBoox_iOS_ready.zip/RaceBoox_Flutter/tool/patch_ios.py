#!/usr/bin/env python3
from pathlib import Path
import plistlib

root = Path(__file__).resolve().parents[1]
plist_path = root / "ios" / "Runner" / "Info.plist"

if not plist_path.exists():
    raise SystemExit(f"Info.plist tidak ditemukan: {plist_path}")

with plist_path.open("rb") as f:
    data = plistlib.load(f)

data["CFBundleDisplayName"] = "RaceBoox"
data["CFBundleName"] = "RaceBoox"
data["NSLocationWhenInUseUsageDescription"] = (
    "RaceBoox memakai GPS untuk mengukur kecepatan, akselerasi, dan merekam rute perjalanan."
)
data["NSLocationAlwaysAndWhenInUseUsageDescription"] = (
    "RaceBoox membutuhkan akses lokasi saat aplikasi aktif dan pada konfigurasi tracking "
    "yang diizinkan sistem."
)
data["NSMotionUsageDescription"] = (
    "RaceBoox menggunakan sensor gerak untuk mendeteksi pergerakan kendaraan."
)

# Background location is only useful/valid when the app's capabilities and
# implementation justify it. Keep the declaration because this project exposes
# a background-tracking setting, but iOS behavior remains OS-controlled.
modes = data.get("UIBackgroundModes", [])
if "location" not in modes:
    modes.append("location")
data["UIBackgroundModes"] = modes

with plist_path.open("wb") as f:
    plistlib.dump(data, f)

# Keep the project name visible and predictable.
print(f"Patched {plist_path}")
