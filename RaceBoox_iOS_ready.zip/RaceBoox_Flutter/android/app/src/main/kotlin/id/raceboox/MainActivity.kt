package id.raceboox

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
