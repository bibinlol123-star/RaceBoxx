# RaceBoox Flutter

Port Flutter lintas platform dari RaceBoox Android native yang dikirim dalam arsip asli.

## Fitur yang sudah dipindahkan

- Dashboard RaceBoox dark/carbon + accent teal/red/orange/purple
- Speedo Meter berbasis GPS
- Trip recorder + statistik hari ini
- Drag Meter dengan target jarak, rolling start, reaction mode, auto-stop
- Range Test, misalnya 60 -> 130 km/h
- History, detail run, compare dua run
- Export CSV melalui share sheet
- Trip list, detail rute sederhana, export GPX
- Settings: km/h / mph, mounting fixed / bag, kalibrasi per kendaraan, threshold, reaction, rolling start, auto-stop
- Penyimpanan lokal via SharedPreferences
- GPS + accelerometer via plugin Flutter yang mendukung Android/iOS
- Keep-screen-on via wakelock_plus

## Menjalankan

### 1. Pastikan Flutter terpasang

Gunakan Flutter yang mendukung Dart 3.10+.

### 2. Ambil dependency

```bash
flutter pub get
```

### 3. Android

```bash
flutter run -d android
```

### 4. iOS

Project ini menyertakan `tool/prepare_ios.sh` untuk membuat ulang folder iOS/Xcode lengkap dengan Flutter di macOS.

```bash
sh tool/prepare_ios.sh
flutter build ipa --release
```

Untuk build iOS pada perangkat fisik/distribusi, Apple code signing tetap diperlukan.
Lihat `IOS_BUILD.md` untuk workflow GitHub Actions dan penjelasan signing.

