# RaceBoox iOS

Project ini sekarang dipersiapkan supaya folder iOS resmi dapat dibuat ulang oleh Flutter.

## Kenapa folder `ios/` tidak disimpan sebagai Xcode project lengkap?

Arsip awal hanya berisi `Info.plist` dan `Podfile`, bukan `Runner.xcodeproj` / `Runner.xcworkspace` lengkap. Karena Flutter/Xcode yang sebenarnya harus menghasilkan project native tersebut, folder itu lebih aman dibuat ulang pada mesin macOS.

## Cara paling mudah

1. Buka project ini di Mac yang sudah memasang Flutter dan Xcode.
2. Jalankan:

```bash
sh tool/prepare_ios.sh
```

3. Untuk testing:

```bash
flutter run -d ios
```

4. Untuk membuat IPA:

```bash
flutter build ipa --release
```

Flutter mendokumentasikan bahwa `flutter build ipa` menghasilkan archive `.xcarchive` dan `.ipa`; untuk perangkat fisik/distribusi, build harus melalui code signing. Xcode/macOS diperlukan untuk build iOS. 

## Build lewat web

Project ini juga sudah diberi workflow GitHub Actions di:

`.github/workflows/ios-build.yml`

Workflow itu memakai runner macOS untuk membuat project iOS dan mencoba menghasilkan build tanpa code signing. Artifact unsigned tidak bisa langsung dipasang ke iPhone.

Untuk IPA yang benar-benar dapat dipasang pada iPhone, signing/provisioning Apple tetap diperlukan.
